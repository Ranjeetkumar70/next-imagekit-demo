import React from "react";

function VideoUploadForm() {
  return <div>assignment</div>;
}

export default VideoUploadForm;
